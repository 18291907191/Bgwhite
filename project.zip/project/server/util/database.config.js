module.exports = {
  jwtSecret: 'Blog',
  db: {
      host: '39.96.41.33',
      user: 'root',
      password: '123456',
      database: 'Blog'
  }
}