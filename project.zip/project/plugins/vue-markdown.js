import Vue from 'vue';
import mavonEditor from 'mavon-editor';
Vue.use(mavonEditor);