<template>
  <section class="wraper">
    即将过年，狗尾草心已飞向家乡。过节后继续建设。敬请期待
  </section>
</template>
<script>
export default {
  
}
</script>
<style lang="less" scoped>

</style>
