<template>
  <section class="container">
    文章详情
  </section>
</template>
<script>
export default {
  
}
</script>
<style lang="less" scoped>

</style>
